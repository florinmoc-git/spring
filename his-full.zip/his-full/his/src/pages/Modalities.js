import React from 'react'

export const Modalities = () => {
  return (
    <div>Modalities</div>
  )
}
