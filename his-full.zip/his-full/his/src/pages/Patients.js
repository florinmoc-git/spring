import React from "react";
import PatientList from "../components/patient/PatientList";

export const Patients = () => {
    return (
        <div>
            <PatientList />
        </div>
    );
};
