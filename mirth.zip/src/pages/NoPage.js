import React from 'react'

export const NoPage = () => {
  return (
    <div>NoPage</div>
  )
}
