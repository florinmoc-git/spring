export const SERVER_URL='http://localhost:8081/';
export const MIRTH_ENDPOINT = "https://localhost:8443/api";
export const username = 'admin';
export const password = 'admin';